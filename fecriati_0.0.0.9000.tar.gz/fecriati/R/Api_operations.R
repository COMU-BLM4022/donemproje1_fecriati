#' Api ile veri yazma islemi
#' @export
post_api <- function() {
  # bu islemler sonraki asamada tanimlanacak
  # yapildi, düzenlenilmeyi bekliyorlar

}


#' Api ile veri cekme islemi
#' @export
gets_api <- function() {
  # bu islemler sonraki asamada tanimlanacak
  # yapildi, düzenlenilmeyi bekliyorlar

}
